<?php

logout();

redirect(u('/'));


