<?php

header('Content-Type: application/javascript; charset=UTF-8') ?>

var url = '<?= URL ?>';
var ws_url = '<?= WS_URL ?>';
