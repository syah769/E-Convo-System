<?php
/**
 * top view
 */
chdir(dirname($_SERVER['DOCUMENT_ROOT']));

/**
 * boot app
 */
require_once 'boot.php';
